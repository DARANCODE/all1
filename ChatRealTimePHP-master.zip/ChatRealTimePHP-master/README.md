# ChatRealTimePHP

### Sử dụng: PHP, MySQL, Ajax

### Giao diện

![alt text](screenshots/sc1.png)
![alt text](screenshots/sc2.png)
![alt text](screenshots/sc3.png)
![alt text](screenshots/sc4.png)
