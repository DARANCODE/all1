# firework
Write a simple firework in HTML, CSS, Javascript
